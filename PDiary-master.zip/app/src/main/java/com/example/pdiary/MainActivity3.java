package com.example.pdiary;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity3 extends Activity {



    //이름,국적,이미지리소스아이디를 가지고 있는 MemberData 클래스의 객체를

    //배열로 보관하기 위한 ArrayList 객체 생성

    //MemberData[] 이렇게 선언하는 일반배열은 배열 개수가 정해져 있어서 나중에 추가,삭제가 불편하죠.

    //배열 요소의 개수를 유동적으로 조절할 수 있는 ArrayList 객체로 data 보관

    ArrayList<MemberData> datas= new ArrayList<MemberData>();



    //ListView 참조변수

    ListView listview;



    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.list_main);



        //이번 예제에서는 우선 직접 코딩으로 멤버정보를 입력하고

        //다른 예제에서 추가/삭제 관련 작업을 해보겠습니다.

        //비정상 회담(요즘 유명하기에 허락없이 도용합니다.-_-)멤버 정보 생성

        datas.add( new MemberData("생일", "2018/04/17", R.drawable.lily));

        datas.add( new MemberData("여자친구", "2018/04/16", R.drawable.lily));

        datas.add( new MemberData("그 날", "2018/04/15", R.drawable.lily));

        datas.add( new MemberData("그 날", "2018/04/14", R.drawable.lily));

        datas.add( new MemberData("그 날", "2018/04/13", R.drawable.lily));

        datas.add( new MemberData("그 날2", "2018/04/12", R.drawable.lily));

        datas.add( new MemberData("그 날3", "2018/04/11", R.drawable.lily));

        datas.add( new MemberData("그 날4", "2018/04/10", R.drawable.lily));

        //귀찮아서 다 못넣겠네요...-_-



        //ListView 객체 찾아와서 참조

        listview= (ListView)findViewById(R.id.listview);



        //AdapterView의 일종인 ListView에 적용할 Adapter 객체 생성

        //MemberData 객체의 정보들(이름, 국적, 이미지)를 적절하게 보여줄 뷰로 만들어주는 Adapter클래스 객체생성

        //이 예제에서는 MemberDataAdapter.java 파일로 클래스를 설계하였음.

        //첫번재 파라미터로 xml 레이아웃 파일을 객체로 만들어 주는 LayoutInflater 객체 얻어와서 전달..

        //두번째 파라미터는 우리가 나열한 Data 배열..

        MemberDataAdapter adapter= new MemberDataAdapter( getLayoutInflater() , datas);



        //위에 만든 Adapter 객체를 AdapterView의 일종인 ListView에 설정.

        listview.setAdapter(adapter);



    }

}



