package com.example.pdiary;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View.OnClickListener;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class writediary extends AppCompatActivity {




    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.writediary);


        }






    public void onClick1 (View v) {

        Intent intent = new Intent(writediary.this, MainActivity4.class);

        startActivity(intent);

        Toast.makeText(getApplicationContext(), "설정 페이지로 넘어갑니다^~^", Toast.LENGTH_LONG).show();

    }


    // onButton1Clicked에 대한 로직
    public void onButtonClicked (View v) {
            Toast.makeText(getApplicationContext(), "저장되었습니다^~^", Toast.LENGTH_LONG).show();
        }

    public void onClick (View v) {
        Toast.makeText(getApplicationContext(), "삭제되었습니다.^~^", Toast.LENGTH_LONG).show();
    }



    }

