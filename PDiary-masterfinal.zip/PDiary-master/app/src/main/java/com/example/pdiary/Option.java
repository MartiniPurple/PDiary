package com.example.pdiary;

import android.app.Activity;

import android.graphics.Color;

import android.os.Bundle;

import android.view.Menu;

import android.view.MenuInflater;

import android.view.MenuItem;

import android.view.View;

import android.widget.Button;

import android.widget.PopupMenu;



public class Option extends Activity {



    Button btnShow;



    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main3);



        //버튼 등록

        btnShow = (Button)findViewById(R.id.btnShow);



    }



    //버튼이 눌렸을때 여기로옴

    public void mOnClick(View v){

        //팝업 메뉴 객체 만듬

        PopupMenu popup = new PopupMenu(this, v);



        //xml파일에 메뉴 정의한것을 가져오기위해서 전개자 선언

        MenuInflater inflater = popup.getMenuInflater();

        Menu menu = popup.getMenu();



        //실제 메뉴 정의한것을 가져오는 부분 menu 객체에 넣어줌

        inflater.inflate(R.menu.activity_menu, menu);



        //메뉴가 클릭했을때 처리하는 부분

        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {



            @Override

            public boolean onMenuItemClick(MenuItem item) {

                // TODO Auto-generated method stub



                //각 메뉴별 아이디를 조사한후 할일을 적어줌

                switch(item.getItemId()){

                    case R.id.popup_red:

                        btnShow.setBackgroundColor(Color.RED);

                        break;

                    case R.id.popup_green:

                        btnShow.setBackgroundColor(Color.GREEN);

                        break;

                    case R.id.popup_blue:

                        btnShow.setBackgroundColor(Color.BLUE);

                        break;

                    case R.id.popup_black:

                        btnShow.setTextColor(Color.BLACK);

                        break;

                    case R.id.popup_white:

                        btnShow.setTextColor(Color.WHITE);

                        break;

                    case R.id.popup_gray:

                        btnShow.setTextColor(Color.GRAY);

                        break;

                }



                return false;

            }

        });



        popup.show();

    }



}



