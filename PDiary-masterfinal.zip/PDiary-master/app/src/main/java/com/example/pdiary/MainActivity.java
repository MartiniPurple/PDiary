package com.example.pdiary;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View.OnClickListener;
import android.view.View;
import android.widget.Button;

import android.view.animation.Animation;

import android.view.animation.AnimationUtils;

import com.github.clans.fab.FloatingActionButton;


public class MainActivity extends AppCompatActivity {

  FloatingActionButton btn_go;
  FloatingActionButton btn_go1;
  FloatingActionButton btn_go2;
  FloatingActionButton btn_go3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainpage);


        btn_go1 = (FloatingActionButton)findViewById(R.id.fab1);
        btn_go1.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), writediary.class);
                startActivity(intent);
                finish();
            }
        });

        btn_go2 = (FloatingActionButton)findViewById(R.id.fab3);
        btn_go2.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity3.class);
                startActivity(intent);
                finish();
            }
        });

        btn_go3 = (FloatingActionButton)findViewById(R.id.fab2);
        btn_go3.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity2.class);
                startActivity(intent);
                finish();
            }
        });

        btn_go = (FloatingActionButton)findViewById(R.id.fab4);
        btn_go.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Outro.class);
                startActivity(intent);
                finish();
            }
        });


        }

                    }

