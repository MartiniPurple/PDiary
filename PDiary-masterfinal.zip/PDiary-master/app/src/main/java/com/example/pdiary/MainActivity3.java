package com.example.pdiary;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity3 extends Activity {




    ArrayList<MemberData> datas= new ArrayList<MemberData>();



    //ListView 참조변수

    ListView listview;



    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.list_main);





        datas.add( new MemberData("생일", "2018/04/17", R.drawable.lily));

        datas.add( new MemberData("연인", "2018/04/16", R.drawable.couple));

        datas.add( new MemberData("마티니 블루", "2018/04/15", R.drawable.torini));

        datas.add( new MemberData("그 날", "2018/04/14", R.drawable.lily));

        datas.add( new MemberData("그 날", "2018/04/13", R.drawable.lily));

        datas.add( new MemberData("그 날2", "2018/04/12", R.drawable.lily));

        datas.add( new MemberData("그 날3", "2018/04/11", R.drawable.lily));

        datas.add( new MemberData("그 날4", "2018/04/10", R.drawable.lily));



        listview= (ListView)findViewById(R.id.listview);





        MemberDataAdapter adapter= new MemberDataAdapter( getLayoutInflater() , datas);





        listview.setAdapter(adapter);



    }

}



