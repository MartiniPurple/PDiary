package sub_list;



public class CustomDTO1 {
    private int resId1;
    private String title1;
    private String content1;

    public int getResId1() {
        return resId1;
    }

    public void setResId1(int resId) {
        this.resId1 = resId;
    }

    public String getTitle1() {
        return title1;
    }

    public void setTitle1(String title) {
        this.title1 = title;
    }

    public String getContent1() {
        return content1;
    }

    public void setContent1(String content) {
        this.content1 = content;
    }
}